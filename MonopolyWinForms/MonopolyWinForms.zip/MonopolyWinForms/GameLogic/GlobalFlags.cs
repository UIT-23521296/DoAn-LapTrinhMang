﻿namespace MonopolyWinForms.GameLogic
{
    public static class GlobalFlags
    {
        public static bool PlayerLeftHandled = false;
    }
}
