﻿namespace buyLand_Home
{
    partial class BuyHome_Land
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BuyHome_Land));
            label1 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            checkBox1 = new CheckBox();
            label2 = new Label();
            button1 = new Button();
            button2 = new Button();
            label3 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            checkBox2 = new CheckBox();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            checkBox3 = new CheckBox();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            checkBox4 = new CheckBox();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            checkBox5 = new CheckBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F);
            label1.Location = new Point(390, 18);
            label1.Name = "label1";
            label1.Size = new Size(231, 45);
            label1.TabIndex = 0;
            label1.Text = "Tân Kỳ Tân Quý";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(checkBox1);
            panel1.Location = new Point(54, 86);
            panel1.Name = "panel1";
            panel1.Size = new Size(147, 189);
            panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(17, 28);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(111, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(38, 148);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(76, 29);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Land";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13F);
            label2.Location = new Point(411, 362);
            label2.Name = "label2";
            label2.Size = new Size(161, 36);
            label2.TabIndex = 5;
            label2.Text = "Rent rate: $0";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13F);
            button1.Location = new Point(145, 362);
            button1.Name = "button1";
            button1.Size = new Size(153, 61);
            button1.TabIndex = 6;
            button1.Text = "Mua";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 13F);
            button2.Location = new Point(692, 362);
            button2.Name = "button2";
            button2.Size = new Size(153, 61);
            button2.TabIndex = 7;
            button2.Text = "Bỏ qua";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13F);
            label3.Location = new Point(410, 442);
            label3.Name = "label3";
            label3.Size = new Size(162, 36);
            label3.TabIndex = 9;
            label3.Text = "The price: $0";
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(checkBox2);
            panel2.Location = new Point(241, 86);
            panel2.Name = "panel2";
            panel2.Size = new Size(147, 189);
            panel2.TabIndex = 11;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(17, 28);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(111, 75);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(21, 148);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(104, 29);
            checkBox2.TabIndex = 0;
            checkBox2.Text = "House 1";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(checkBox3);
            panel3.Location = new Point(425, 86);
            panel3.Name = "panel3";
            panel3.Size = new Size(147, 189);
            panel3.TabIndex = 12;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(17, 28);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(111, 75);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(21, 148);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(104, 29);
            checkBox3.TabIndex = 0;
            checkBox3.Text = "House 2";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // panel4
            // 
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(checkBox4);
            panel4.Location = new Point(615, 86);
            panel4.Name = "panel4";
            panel4.Size = new Size(147, 189);
            panel4.TabIndex = 13;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(17, 28);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(111, 75);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(21, 148);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(104, 29);
            checkBox4.TabIndex = 0;
            checkBox4.Text = "House 3";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // panel5
            // 
            panel5.Controls.Add(pictureBox5);
            panel5.Controls.Add(checkBox5);
            panel5.Location = new Point(801, 86);
            panel5.Name = "panel5";
            panel5.Size = new Size(147, 189);
            panel5.TabIndex = 14;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(17, 28);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(111, 75);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 11;
            pictureBox5.TabStop = false;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(32, 148);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(81, 29);
            checkBox5.TabIndex = 0;
            checkBox5.Text = "Hotel";
            checkBox5.UseVisualStyleBackColor = true;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // BuyHome_Land
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1003, 531);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "BuyHome_Land";
            Text = "BuyHome_Land";
            Load += BuyLand_Home_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private CheckBox checkBox1;
        private Label label2;
        private Button button1;
        private Button button2;
        private Label label3;
        private PictureBox pictureBox1;
        private Panel panel2;
        private PictureBox pictureBox2;
        private CheckBox checkBox2;
        private Panel panel3;
        private PictureBox pictureBox3;
        private CheckBox checkBox3;
        private Panel panel4;
        private PictureBox pictureBox4;
        private CheckBox checkBox4;
        private Panel panel5;
        private PictureBox pictureBox5;
        private CheckBox checkBox5;
    }
}